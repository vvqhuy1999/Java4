package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import Daos.*;
import Impl.*;
import Entity.*;

import java.io.IOException;
import java.util.List;

/**
 * Servlet implementation class UserLayout
 */
@WebServlet({ "/user/home", "/user/myFavorites", "/user/login", "/user/registration" })
public class UserLayout extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserLayout() {
		super();
		// TODO Auto-generated constructor stub
	}

	private UserDAO userDao = new UserDAOImpl();
	private VideoDAO videoDao = new VideoDAOImpl();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uri = request.getRequestURI();
		if (uri.contains("home")) {
			// thực hiện truy xuất dữ liệu
			List<Video> videos = videoDao.findAll();
			request.setAttribute("videos", videos);
			request.setAttribute("page", "/user/Home.jsp");
		} else if (uri.contains("myFavorites")) {
			// thực hiện truy xuất dữ liệu
			request.setAttribute("page", "/user/Favorites.jsp");
		} else if (uri.contains("login")) {
			// thực hiện truy xuất dữ liệu
			if ("POST".equalsIgnoreCase(request.getMethod())) {
				handleLogin(request, response);
				return;
			} else {
				// Kiểm tra nếu người dùng đã đăng nhập (có session)
		        HttpSession session = request.getSession(false); // false để không tạo session mới nếu chưa có
		        if (session != null && session.getAttribute("user") != null) {
		            // Nếu người dùng đã đăng nhập, chuyển hướng đến trang chủ (index.jsp)
		        	response.sendRedirect(request.getContextPath() + "/views/userLayout.jsp");
					request.setAttribute("page", "/user/Home.jsp");
//		            resp.sendRedirect("index.jsp");
		        } else {
		            // Nếu chưa đăng nhập, hiển thị trang login.jsp
		            request.setAttribute("page", "/user/Login.jsp");
		        }
			}
		} else if (uri.contains("registration")) {
			// thực hiện truy xuất dữ liệu
			request.setAttribute("page", "/user/Registration.jsp");
		} else {
			System.out.println(uri);
		}
		// Chuyển hướng về trang admin layout
		request.getRequestDispatcher("/views/userLayout.jsp").forward(request, response);
	}

	private void handleLogin(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		User user = userDao.findById(id);
		if (user == null) {
			request.setAttribute("error", "Sai username!");
			request.setAttribute("page", "/user/Login.jsp");
			request.getRequestDispatcher("/views/userLayout.jsp").forward(request, response);
		} else if (!user.getPassword().equals(password)) {
			request.setAttribute("error", "Sai password!");
			request.setAttribute("page", "/user/Login.jsp");
			request.getRequestDispatcher("/views/userLayout.jsp").forward(request, response);
		} else {
			HttpSession session = request.getSession();
			session.setAttribute("user", user);
			session.setAttribute("isAdmin", user.getAdmin());
			if (user.getAdmin()) {
				response.sendRedirect(request.getContextPath() + "/views/adminLayout.jsp");
			} else {
				response.sendRedirect(request.getContextPath() + "/views/userLayout.jsp");
				request.setAttribute("page", "/user/Home.jsp");
			}
		}
	}
}
