package Daos;

import Entity.*;

public interface LogDAO {
    void create(Log log); // Phương thức thêm log mới vào CSDL
}
