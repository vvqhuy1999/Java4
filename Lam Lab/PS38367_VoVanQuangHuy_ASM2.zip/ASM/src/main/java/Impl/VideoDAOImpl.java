package Impl;

import Daos.*;
import Entity.*;
import Utils.XJPA;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

import java.util.List;

public class VideoDAOImpl implements VideoDAO {
	private EntityManager em = XJPA.getEntityManager();

	@Override
	public Video findById(String id) {
		return em.find(Video.class, id);
	}

	@Override
	public List<Video> findAll() {
		return em.createQuery("SELECT v FROM Video v", Video.class).getResultList();
	}

	@Override
	public void save(Video video) {
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		em.persist(video);
		transaction.commit();
	}

	@Override
	public void update(Video video) {
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		em.merge(video);
		transaction.commit();
	}

	@Override
	public void delete(Video video) {
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		em.remove(em.contains(video) ? video : em.merge(video));
		transaction.commit();
	}

	public List<Video> findRelatedVideos(String videoId) {
		String jpql = "SELECT v FROM Video v WHERE v.id != :videoId ORDER BY RAND()";
		TypedQuery<Video> query = em.createQuery(jpql, Video.class);
		query.setParameter("videoId", videoId);
		query.setMaxResults(20);
		return query.getResultList();
	}

	@Override
	public List<Video> findByTitle(String title) {
		String jpql = "SELECT v FROM Video v WHERE v.title LIKE :title";
		TypedQuery<Video> query = em.createQuery(jpql, Video.class);
		query.setParameter("title", "%" + title + "%");
		return query.getResultList();
	}

	public static void main(String[] args) {
		VideoDAOImpl videoDAO = new VideoDAOImpl();

//		List<Video> allVideos = videoDAO.findAll();
//		for (Video v : allVideos) {
//			System.out.println(v.getId() + "," + v.getTitle());
//		}

		String keyword = "Shape";
		List<Video> videos = videoDAO.findByTitle(keyword);
		if (videos.isEmpty()) {
			System.out.println("Không tìm thấy " + keyword);
		} else {
			for (Video video : videos) {
				System.out.println("Video ID: " + video.getId() + ", Title: " + video.getTitle());
			}
		}
	}
}
